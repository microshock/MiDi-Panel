package ru.midipanel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.util.Base64;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 4101;
    private static final int SAVE_FILE = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingName;
    private byte[] pendingBytes;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(9,13,24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,13,24));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(9,13,24));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidBridge(), "MiDiAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) && "127.0.0.1".equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Выбрать аудиофайл"), FILE_PICKER);
                return true;
            }
        });
        setContentView(webView);
        new Thread(() -> startEmbeddedServer(), "MiDiPanel-startup").start();
    }

    private void startEmbeddedServer() {
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            File panelDir = new File(getFilesDir(), "panel");
            copyAssetTree("panel", panelDir);
            String url = Python.getInstance().getModule("android_server").callAttr("start_server", panelDir.getAbsolutePath()).toString();
            runOnUiThread(() -> webView.loadUrl(url));
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Ошибка запуска сервера: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void copyAssetTree(String assetPath, File target) throws Exception {
        String[] children = getAssets().list(assetPath);
        if (children != null && children.length > 0) {
            if (!target.exists() && !target.mkdirs()) throw new Exception("Не удалось создать каталог " + target);
            for (String child : children) copyAssetTree(assetPath + "/" + child, new File(target, child));
        } else {
            if (target.exists()) return;
            File parent = target.getParentFile(); if (parent != null) parent.mkdirs();
            try (InputStream in = getAssets().open(assetPath); OutputStream out = new FileOutputStream(target)) {
                byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveFile(String name, String base64) {
            try {
                pendingName = name == null ? "download.bin" : name.replaceAll("[^a-zA-Z0-9._-]", "_");
                pendingBytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(intent, SAVE_FILE);
                });
            } catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Не удалось подготовить файл", Toast.LENGTH_SHORT).show()); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER) {
            if (fileCallback != null) { fileCallback.onReceiveValue(resultCode == RESULT_OK && data != null ? new Uri[]{data.getData()} : null); fileCallback = null; }
        } else if (requestCode == SAVE_FILE && resultCode == RESULT_OK && data != null && pendingBytes != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) { out.write(pendingBytes); Toast.makeText(this, "Файл сохранён", Toast.LENGTH_SHORT).show(); }
            catch (Exception e) { Toast.makeText(this, "Ошибка сохранения файла", Toast.LENGTH_SHORT).show(); }
            pendingBytes = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}

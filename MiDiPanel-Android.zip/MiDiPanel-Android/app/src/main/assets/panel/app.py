#!/usr/bin/env python3
# Yandex Station MIDI (Cucumber) LED Web Panel
import os, re, threading, time, shlex, uuid, posixpath
from io import BytesIO
import paramiko
from flask import Flask, jsonify, render_template, request, send_file

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = 30 * 1024 * 1024
AUDIO_ROOT = "/system/vendor/quasar/sounds"
AUDIO_BACKUP_ROOT = "/data/quasar/cucumber-studio-audio/originals"
AUDIO_EXTENSIONS = (".opus", ".ogg", ".oga", ".mp3", ".wav", ".flac", ".aac", ".m4a", ".amr", ".pcm", ".raw", ".aiff", ".aif", ".wma", ".3gp", ".caf", ".au", ".snd")
DEFAULT_HOST = os.environ.get("STATION_HOST", "192.168.1.100")
DEFAULT_PORT = int(os.environ.get("STATION_SSH_PORT", "22"))
SSH_USER = os.environ.get("STATION_SSH_USER", "root")
lock = threading.RLock()
# Independent animation workers: ring, logo and clock must not cancel each other.
_animation_lock = threading.RLock()
_animation_events = {name: threading.Event() for name in ("ring", "logo", "clock")}
_animation_generations = {name: 0 for name in ("ring", "logo", "clock")}
_animation_threads = {}
screen_locked = False
_monitor_cpu_previous = None
_monitor_lock = threading.Lock()
ssh_client = None
ssh_host = DEFAULT_HOST
ssh_port = DEFAULT_PORT
ssh_password = ""
LED_RE = re.compile(r"^cucumber:(?:red|green|blue|white):(?:ring\d{1,2}|logo\d|clock-[a-z0-9-]+)$")
GROUPS = {
    "ring": re.compile(r"^cucumber:(?:red|green|blue):ring\d{1,2}$"),
    "logo": re.compile(r"^cucumber:(?:red|green|blue):logo\d$"),
    "clock": re.compile(r"^cucumber:white:clock-[a-z0-9-]+$"),
}

def disconnect_ssh():
    global ssh_client
    with lock:
        if ssh_client is not None:
            try: ssh_client.close()
            except Exception: pass
        ssh_client = None

def connect_ssh(host, port, password):
    global ssh_client, ssh_host, ssh_port, ssh_password
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # An empty password is valid: Paramiko can then try SSH keys/agent auth.
    client.connect(hostname=host, port=port, username=SSH_USER,
                   password=(password if password else None),
                   timeout=6, banner_timeout=6, auth_timeout=6,
                   look_for_keys=True, allow_agent=True)
    # SSH keepalive packets help prevent idle/NAT timeouts; reconnect logic below
    # handles cases where the Wi-Fi/router/sshd still drops the TCP connection.
    client.get_transport().set_keepalive(15)
    with lock:
        if ssh_client is not None:
            try: ssh_client.close()
            except Exception: pass
        ssh_client, ssh_host, ssh_port, ssh_password = client, host, port, password

def _ssh_is_active():
    transport = ssh_client.get_transport() if ssh_client is not None else None
    return bool(transport and transport.is_active() and transport.is_authenticated())

def _reconnect_ssh():
    # Credentials are held only in process memory, just as during initial connect.
    if not ssh_host:
        raise RuntimeError("SSH-соединение потеряно. Подключи колонку заново через форму SSH.")
    connect_ssh(ssh_host, ssh_port, ssh_password)
    if not _ssh_is_active():
        raise RuntimeError("Не удалось восстановить SSH-соединение с колонкой.")

def shell(script, timeout=6):
    last_error = None
    # Retry a failed SSH operation after reconnecting. LED writes are idempotent,
    # so repeating a frame command is safe if the connection failed mid-response.
    for attempt in range(2):
        with lock:
            try:
                if not _ssh_is_active():
                    _reconnect_ssh()
                stdin, stdout, stderr = ssh_client.exec_command(script, timeout=timeout)
                out = stdout.read().decode("utf-8", "replace")
                err = stderr.read().decode("utf-8", "replace")
                code = stdout.channel.recv_exit_status()
                return type("SSHResult", (), {"stdout": out, "stderr": err, "returncode": code})()
            except Exception as exc:
                last_error = exc
                if ssh_client is not None:
                    try: ssh_client.close()
                    except Exception: pass
                # Mark dead client, but retain credentials so the next iteration can reconnect.
                globals()["ssh_client"] = None
                if attempt == 0:
                    try:
                        _reconnect_ssh()
                    except Exception as reconnect_error:
                        last_error = reconnect_error
    raise RuntimeError("SSH временно недоступен; повторное подключение не удалось: " + str(last_error))

def connected():
    try:
        r = shell("printf STATION_SSH_OK", 4)
        return r.returncode == 0 and "STATION_SSH_OK" in r.stdout
    except Exception:
        return False

def led_names():
    try:
        r = shell("ls -1 /sys/class/leds 2>/dev/null", 5)
        if r.returncode not in (0, 1): return []
        names = [x.strip() for x in r.stdout.splitlines()]
        return sorted(n for n in names if LED_RE.fullmatch(n))
    except Exception:
        return []

def read_brightness(name):
    if not LED_RE.fullmatch(name): return 0
    try:
        r = shell("cat " + "/sys/class/leds/" + name + "/brightness 2>/dev/null", 3)
        return max(0, min(255, int(r.stdout.strip())))
    except Exception:
        return 0

def write_led(name, value):
    if not LED_RE.fullmatch(name): raise ValueError("Недопустимое имя светодиода")
    value = max(0, min(255, int(value)))
    # name is constrained by LED_RE; numeric brightness is clamped.
    r = shell("echo " + str(value) + " > /sys/class/leds/" + name + "/brightness", 4)
    if r.returncode:
        raise RuntimeError((r.stderr or r.stdout or "Не удалось записать яркость").strip())
    return value

def stop_animation(target=None):
    """Stop one target, or all targets when target is None."""
    targets = (target,) if target in _animation_events else tuple(_animation_events)
    with _animation_lock:
        for name in targets:
            _animation_events[name].set()
            _animation_generations[name] += 1

def rgb_names(group, idx):
    return [f"cucumber:{color}:{group}{idx}" for color in ("red","green","blue")]

def set_rgb_group(group, idx, rgb):
    prefix = "ring" if group == "ring" else "logo"
    names = rgb_names(prefix, idx)
    commands = []
    for name, value in zip(names, rgb):
        if LED_RE.fullmatch(name):
            commands.append("echo " + str(max(0, min(255, int(value)))) +
                            " > /sys/class/leds/" + name + "/brightness")
    if commands:
        result = shell(" ; ".join(commands), 4)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout or "Ошибка записи RGB").strip())

def set_clock_frame(values):
    """Apply every clock LED in one SSH command so paired segments change together."""
    commands = []
    for name, value in values.items():
        if not LED_RE.fullmatch(name) or not GROUPS["clock"].fullmatch(name):
            raise ValueError("Недопустимое имя сегмента часов")
        level = max(0, min(255, int(value)))
        commands.append("echo " + str(level) + " > /sys/class/leds/" + name + "/brightness")
    if commands:
        result = shell(" ; ".join(commands), 6)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout or "Не удалось применить кадр часов").strip())


def set_rgb_frame(group, colors):
    prefix = "ring" if group == "ring" else "logo"
    commands = []
    for idx, rgb in enumerate(colors):
        for color, value in zip(("red", "green", "blue"), rgb):
            name = f"cucumber:{color}:{prefix}{idx}"
            if LED_RE.fullmatch(name):
                commands.append("echo " + str(max(0, min(255, int(value)))) +
                                " > /sys/class/leds/" + name + "/brightness")
    if commands:
        result = shell(" ; ".join(commands), 6)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout or "Ошибка записи RGB").strip())

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/status")
def status():
    try:
        ok = connected()
        names = led_names() if ok else []
        groups = {"ring": [], "logo": [], "clock": []}
        for n in names:
            for g, rx in GROUPS.items():
                if rx.fullmatch(n): groups[g].append(n)
        values = {n: read_brightness(n) for n in names}
        return jsonify(ok=True, connected=ok, target=f"{ssh_host}:{ssh_port}", ssh_user=SSH_USER,
                       leds=names, groups=groups, values=values, screen_locked=screen_locked)
    except Exception as e:
        return jsonify(ok=False, connected=False, target=f"{ssh_host}:{ssh_port}", error=str(e)), 200

@app.get("/api/monitoring")
def monitoring():
    """Read live system metrics from the connected Station Midi over SSH."""
    global _monitor_cpu_previous
    try:
        if not _ssh_is_active():
            return jsonify(ok=False, error="Сначала подключись к колонке по SSH."), 400
        script = r"""awk '/^MemTotal:|^MemAvailable:|^MemFree:/ {print $1, $2}' /proc/meminfo
printf 'CPUSTAT '; head -1 /proc/stat
for z in /sys/class/thermal/thermal_zone*; do
  [ -r "$z/type" ] && [ -r "$z/temp" ] || continue
  printf 'THERMAL\n'; cat "$z/type"; cat "$z/temp"
done
for key in scaling_cur_freq scaling_max_freq; do
  f="/sys/devices/system/cpu/cpu0/cpufreq/$key"
  [ -r "$f" ] && printf 'FREQ %s ' "$key" && cat "$f"
done
for f in /sys/class/hwmon/hwmon*/temp*_input; do
  [ -r "$f" ] || continue
  printf 'HWMON %s ' "$f"; cat "$f"
done"""
        result = shell(script, timeout=7)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or "Не удалось прочитать системные показатели").strip())
        values = {"memory_total_kb": None, "memory_available_kb": None, "memory_free_kb": None,
                  "cpu_load_percent": None, "temperature_c": None, "temperature_type": None,
                  "cpu_current_khz": None, "cpu_max_khz": None, "ram_temperature_c": None}
        cpu_now = None
        thermal = []
        lines = iter(result.stdout.splitlines())
        for line in lines:
            parts = line.split()
            if not parts: continue
            if parts[0] in ("MemTotal:", "MemAvailable:", "MemFree:") and len(parts) >= 2:
                key = {"MemTotal:": "memory_total_kb", "MemAvailable:": "memory_available_kb", "MemFree:": "memory_free_kb"}[parts[0]]
                values[key] = int(parts[1])
            elif parts[0] == "CPUSTAT" and len(parts) >= 5:
                cpu_now = [int(x) for x in parts[2:]]
            elif parts[0] == "THERMAL":
                # BusyBox shell prints each thermal record on one line: THERMAL type temp.
                # Accept the earlier two-line format as well for compatibility.
                if len(parts) >= 3:
                    kind, raw = parts[1], parts[2]
                else:
                    kind = next(lines, "").strip()
                    raw = next(lines, "").strip()
                try: temp = int(raw) / 1000.0
                except (ValueError, TypeError): continue
                thermal.append((kind, temp))
            elif parts[0] == "FREQ" and len(parts) >= 3:
                try:
                    if parts[1] == "scaling_cur_freq": values["cpu_current_khz"] = int(parts[2])
                    elif parts[1] == "scaling_max_freq": values["cpu_max_khz"] = int(parts[2])
                except ValueError: pass
            elif parts[0] == "HWMON" and len(parts) >= 3:
                try:
                    temp = int(parts[2]) / 1000.0
                    if "mem" in parts[1].lower() or "ddr" in parts[1].lower() or "ram" in parts[1].lower():
                        values["ram_temperature_c"] = temp
                except ValueError: pass
        for kind, temp in thermal:
            if values["temperature_c"] is None or "soc" in kind.lower() or "cpu" in kind.lower():
                values["temperature_type"], values["temperature_c"] = kind, temp
            if "ram" in kind.lower() or "ddr" in kind.lower() or "mem" in kind.lower():
                values["ram_temperature_c"] = temp
        if cpu_now is not None:
            idle = cpu_now[3] + (cpu_now[4] if len(cpu_now) > 4 else 0)
            total = sum(cpu_now)
            with _monitor_lock:
                previous = _monitor_cpu_previous
                _monitor_cpu_previous = (total, idle)
            if previous and total > previous[0]:
                delta_total = total - previous[0]
                delta_idle = idle - previous[1]
                values["cpu_load_percent"] = round(max(0, min(100, 100 * (delta_total - delta_idle) / delta_total)), 1)
        values["ok"] = True
        values["memory_used_kb"] = max(0, values["memory_total_kb"] - values["memory_available_kb"]) if values["memory_total_kb"] is not None and values["memory_available_kb"] is not None else None
        return jsonify(values)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.post("/api/connect")
def connect():
    data = request.get_json(silent=True) or {}
    host = str(data.get("host", "")).strip()
    password = str(data.get("password", ""))
    try: port = int(data.get("port", 22))
    except (TypeError, ValueError): port = 0
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,253}", host) or not (1 <= port <= 65535):
        return jsonify(ok=False, error="Проверь IP-адрес и порт SSH."), 400
    try:
        connect_ssh(host, port, password)
        return jsonify(ok=connected(), target=f"{host}:{port}")
    except Exception as e:
        disconnect_ssh()
        return jsonify(ok=False, error="SSH-подключение не удалось: " + str(e)), 400



def audio_paths():
    """List every recognized audio file in Quasar's system-sound tree."""
    patterns = " -o ".join("-iname " + shlex.quote("*" + ext) for ext in AUDIO_EXTENSIONS)
    script = "find " + shlex.quote(AUDIO_ROOT) + " -type f \\( " + patterns + " \\) -print 2>/dev/null | sort"
    result = shell(script, timeout=20)
    if result.returncode not in (0, 1):
        raise RuntimeError((result.stderr or "Не удалось просканировать системные звуки").strip())
    prefix = AUDIO_ROOT + "/"
    return sorted({line.strip() for line in result.stdout.splitlines()
                   if line.strip().startswith(prefix) and "\n" not in line}, key=str.casefold)


def validate_audio_path(path):
    path = str(path or "")
    if not path.startswith(AUDIO_ROOT + "/") or ".." in path.split("/") or "\x00" in path:
        raise ValueError("Недопустимый путь к аудиофайлу")
    # Do not rescan the entire sound tree for every download/play request. On
    # firmware with many language packs this was slow and could make downloads fail.
    check = shell("[ -f " + shlex.quote(path) + " ] && echo AUDIO_FILE_OK || echo AUDIO_FILE_MISSING", timeout=8)
    if check.returncode != 0 or check.stdout.strip() != "AUDIO_FILE_OK":
        raise ValueError("Аудиофайл не найден на колонке или недоступен")
    return path


def audio_backup_path(path):
    rel = path[len(AUDIO_ROOT) + 1:]
    return AUDIO_BACKUP_ROOT + "/" + rel


def sftp_read_bytes(path):
    """Read a sound over an ordinary SSH exec channel, avoiding SFTP negotiation."""
    quoted = shlex.quote(path)
    result = shell(
        "if command -v base64 >/dev/null 2>&1; then base64 " + quoted +
        "; elif command -v busybox >/dev/null 2>&1; then busybox base64 " + quoted +
        "; else echo AUDIO_BASE64_UNAVAILABLE >&2; exit 127; fi",
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "Не удалось прочитать аудиофайл по SSH").strip())
    import base64
    try:
        return base64.b64decode("".join(result.stdout.split()), validate=True)
    except Exception as exc:
        raise RuntimeError("Колонка вернула повреждённые данные аудиофайла") from exc


def ssh_write_bytes(path, data, timeout=90):
    """Upload bytes through an ordinary SSH exec channel, without SFTP subsystem."""
    import base64
    encoded = base64.b64encode(data)
    command = "base64 -d > " + shlex.quote(path)
    last_error = None
    for attempt in range(2):
        channel = None
        try:
            with lock:
                if not _ssh_is_active():
                    _reconnect_ssh()
                transport = ssh_client.get_transport()
                channel = transport.open_session(timeout=8)
                channel.settimeout(timeout)
                channel.exec_command(command)
                # Send encoded payload in manageable blocks; base64 output is ASCII.
                for offset in range(0, len(encoded), 48 * 1024):
                    channel.sendall(encoded[offset:offset + 48 * 1024])
                channel.shutdown_write()
                out_parts, err_parts = [], []
                while not channel.exit_status_ready():
                    if channel.recv_ready(): out_parts.append(channel.recv(4096))
                    if channel.recv_stderr_ready(): err_parts.append(channel.recv_stderr(4096))
                    time.sleep(0.01)
                while channel.recv_ready(): out_parts.append(channel.recv(4096))
                while channel.recv_stderr_ready(): err_parts.append(channel.recv_stderr(4096))
                code = channel.recv_exit_status()
                if code != 0:
                    raise RuntimeError((b''.join(err_parts).decode('utf-8','replace') or 'Удалённая команда base64 -d завершилась с ошибкой').strip())
                return
        except Exception as exc:
            last_error = exc
            if channel is not None:
                try: channel.close()
                except Exception: pass
            if attempt == 0:
                try:
                    disconnect_ssh()
                    _reconnect_ssh()
                except Exception as reconnect_error:
                    last_error = reconnect_error
    raise RuntimeError("Не удалось передать файл по SSH без SFTP: " + str(last_error))


def remount_copy_script(target, source, make_backup=False):
    """Copy source bytes into an existing system sound while restoring prior RO state."""
    t, src = shlex.quote(target), shlex.quote(source)
    backup = shlex.quote(audio_backup_path(target))
    backup_step = (f'mkdir -p "$(dirname {backup})" || exit 21; '
                   f'if [ ! -f {backup} ]; then cp -p {t} {backup} || exit 22; fi; ') if make_backup else ''
    return f"""target={t}; source={src};
[ -f "$source" ] || {{ echo 'AUDIO_ERROR: временный или резервный аудиофайл не найден'; exit 24; }}
{backup_step}
mountinfo=$(awk -v p="$target" 'BEGIN{{best=-1;mp="/";opts=""}} {{m=$2;if(m=="/" || p==m || index(p,m "/")==1){{if(length(m)>best){{best=length(m);mp=m;opts=$4}}}}}} END{{print mp "|" opts}}' /proc/mounts)
mp=${{mountinfo%%|*}}; opts=${{mountinfo#*|}}; was_ro=0
case ",$opts," in *,ro,*) was_ro=1;; esac
if [ "$was_ro" = 1 ]; then mount -o remount,rw "$mp" || {{ echo 'AUDIO_ERROR: не удалось перемонтировать файловую систему на запись'; exit 23; }}; fi
if [ ! -f "$target" ]; then
  if [ -f "$source" ]; then cp -p "$source" "$target"; else echo 'AUDIO_ERROR: исходный файл отсутствует'; rc=24; fi
else
  cat "$source" > "$target" || rc=25
fi
rc=${{rc:-0}}
if [ "$was_ro" = 1 ]; then mount -o remount,ro "$mp" || echo 'AUDIO_WARNING: не удалось вернуть режим только чтение'; fi
[ "$rc" = 0 ] || exit "$rc"
echo AUDIO_WRITE_OK
"""

@app.get("/api/audio/files")
def audio_files():
    try:
        paths = audio_paths()
        files = []
        for path in paths:
            rel = path[len(AUDIO_ROOT) + 1:]
            parts = rel.split("/")
            language = next((part for part in parts[:-1]
                             if re.fullmatch(r"[a-zA-Z]{2,3}[-_][a-zA-Z]{2,4}", part)), None)
            if not language:
                language = "Общие" if "common" in [x.lower() for x in parts[:-1]] else "Без языковой метки"
            backup = audio_backup_path(path)
            check = shell("if [ -f " + shlex.quote(backup) + " ]; then if cmp -s " + shlex.quote(path) + " " + shlex.quote(backup) + "; then echo ORIGINAL; else echo CUSTOM; fi; else echo NO_BACKUP; fi", timeout=4)
            status = check.stdout.strip()
            files.append({"path": path, "name": posixpath.basename(path), "language": language,
                          "relative_path": rel, "customized": status == "CUSTOM", "has_backup": status != "NO_BACKUP"})
        return jsonify(ok=True, files=files, count=len(files))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.post("/api/audio/play")
def audio_play():
    try:
        path = validate_audio_path((request.get_json(silent=True) or {}).get("path"))
        pipeline = "filesrc location=" + path + " ! decodebin ! audioconvert ! audioresample ! alsasink"
        command = ("mkdir -p /tmp; "
                   "if [ -s /tmp/cucumber-studio-audio.pid ]; then kill $(cat /tmp/cucumber-studio-audio.pid) 2>/dev/null || true; fi; "
                   "cd /system/vendor/quasar && "
                   "nohup sh -c " + shlex.quote("LD_LIBRARY_PATH=/system/vendor/quasar:/system/vendor/quasar/libs GST_PLUGIN_PATH=/system/vendor/quasar/libs /system/vendor/quasar/maind --gst-launch " + shlex.quote(pipeline)) +
                   " >/tmp/cucumber-studio-audio-play.log 2>&1 </dev/null & echo $! >/tmp/cucumber-studio-audio.pid; echo AUDIO_PLAY_STARTED")
        result = shell(command, timeout=6)
        if result.returncode != 0 or "AUDIO_PLAY_STARTED" not in result.stdout:
            raise RuntimeError((result.stderr or result.stdout or "Не удалось запустить воспроизведение на колонке").strip())
        return jsonify(ok=True, message="Воспроизведение запущено на колонке", path=path)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.get("/api/audio/download")
def audio_download():
    try:
        path = validate_audio_path(request.args.get("path"))
        backup = audio_backup_path(path)
        check = shell("[ -f " + shlex.quote(backup) + " ] && echo BACKUP || echo CURRENT", timeout=8)
        source = backup if check.stdout.strip() == "BACKUP" else path
        data = sftp_read_bytes(source)
        if not data:
            raise RuntimeError("Файл пустой или не удалось прочитать его содержимое по SSH/SFTP")
        response = send_file(BytesIO(data), as_attachment=True, download_name=posixpath.basename(path),
                             mimetype="application/octet-stream", max_age=0, conditional=False)
        response.headers["Content-Length"] = str(len(data))
        response.headers["Cache-Control"] = "no-store"
        return response
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.post("/api/audio/create-backup")
def audio_create_backup():
    """Create/verify a baseline in one remote script to avoid many SSH execs."""
    try:
        patterns = " -o ".join("-iname " + shlex.quote("*" + ext) for ext in AUDIO_EXTENSIONS)
        root = shlex.quote(AUDIO_ROOT)
        backup_root = shlex.quote(AUDIO_BACKUP_ROOT)
        script = """set -e
root=ROOT_PLACEHOLDER
backup_root=BACKUP_PLACEHOLDER
list="/tmp/cucumber-audio-list.$$"
find "$root" -type f \( PATTERNS_PLACEHOLDER \) -print | sort > "$list" || { rm -f "$list"; echo AUDIO_BACKUP_SCAN_FAILED; exit 10; }
count=$(wc -l < "$list" | tr -d ' ')
[ "$count" -gt 0 ] || { rm -f "$list"; echo AUDIO_BACKUP_NO_FILES; exit 11; }
while IFS= read -r path; do
  rel=${path#"$root"/}
  backup="$backup_root/$rel"
  if [ -f "$backup" ] && ! cmp -s "$path" "$backup"; then printf 'AUDIO_CUSTOM:%s\n' "$path"; fi
done < "$list" > /tmp/cucumber-audio-preflight.$$
if [ -s /tmp/cucumber-audio-preflight.$$ ]; then cat /tmp/cucumber-audio-preflight.$$; rm -f "$list" /tmp/cucumber-audio-preflight.$$; exit 12; fi
rm -f /tmp/cucumber-audio-preflight.$$
while IFS= read -r path; do
  rel=${path#"$root"/}
  backup="$backup_root/$rel"
  mkdir -p "$(dirname "$backup")" || { rm -f "$list"; echo AUDIO_BACKUP_COPY_FAILED; exit 13; }
  if [ ! -f "$backup" ]; then cp -p "$path" "$backup" || { rm -f "$list"; echo AUDIO_BACKUP_COPY_FAILED; exit 14; }; fi
  cmp -s "$path" "$backup" || { printf 'AUDIO_VERIFY_FAILED:%s\n' "$path"; rm -f "$list"; exit 15; }
done < "$list"
rm -f "$list"
echo "AUDIO_BACKUP_CREATED:$count"
"""
        script = script.replace("ROOT_PLACEHOLDER", root).replace("BACKUP_PLACEHOLDER", backup_root).replace("PATTERNS_PLACEHOLDER", patterns)
        result = shell(script, timeout=180)
        customized = [line.split(":", 1)[1] for line in result.stdout.splitlines() if line.startswith("AUDIO_CUSTOM:")]
        if customized:
            names = ", ".join(posixpath.basename(x) for x in customized[:8])
            more = " и ещё " + str(len(customized)-8) if len(customized) > 8 else ""
            return jsonify(ok=False, error="Найдены заменённые файлы: " + names + more + ". Сначала восстанови оригиналы для всех изменённых звуков, затем повтори создание резервной копии."), 409
        if result.returncode != 0 or "AUDIO_BACKUP_CREATED:" not in result.stdout:
            if "AUDIO_BACKUP_NO_FILES" in result.stdout:
                message = "Системные аудиофайлы не найдены — резервная копия не создана."
            elif "AUDIO_VERIFY_FAILED:" in result.stdout:
                bad = [x.split(":", 1)[1] for x in result.stdout.splitlines() if x.startswith("AUDIO_VERIFY_FAILED:")]
                message = "Резервная копия не прошла проверку для: " + ", ".join(posixpath.basename(x) for x in bad[:8])
            else:
                message = "Не удалось полностью создать и проверить резервную копию. Проверь соединение SSH, свободное место и права записи на колонке."
            raise RuntimeError(message)
        count = int(result.stdout.split("AUDIO_BACKUP_CREATED:", 1)[1].splitlines()[0].strip())
        return jsonify(ok=True, count=count, message=f"Резервная копия создана и проверена: {count} файлов.")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.post("/api/audio/upload")
def audio_upload():
    remote_input = remote_output = None
    try:
        path = validate_audio_path(request.form.get("path"))
        upload = request.files.get("file")
        if upload is None or not upload.filename:
            raise ValueError("Выбери аудиофайл для загрузки")
        original_ext = posixpath.splitext(path)[1].lower()
        upload_ext = posixpath.splitext(upload.filename)[1].lower()
        token = uuid.uuid4().hex
        tmp_root = "/data/quasar/cucumber-studio-audio/tmp"
        shell("mkdir -p " + shlex.quote(tmp_root), timeout=5)
        remote_input = tmp_root + "/upload-" + token + (upload_ext if re.fullmatch(r"\.[a-zA-Z0-9]{1,8}", upload_ext or "") else ".bin")
        remote_output = tmp_root + "/converted-" + token + ".tmp"
        # The Station's SSH server may not provide a working SFTP subsystem.
        # Transfer through an ordinary SSH exec channel instead.
        upload_data = upload.read()
        if not upload_data:
            raise ValueError("Выбранный аудиофайл пустой")
        ssh_write_bytes(remote_input, upload_data, timeout=90)
        if original_ext == ".opus" and upload_ext != ".opus":
            pipeline = ("filesrc location=" + remote_input +
                        " ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=48000,channels=1 ! opusenc ! oggmux ! filesink location=" + remote_output)
            cmd = ("cd /system/vendor/quasar && LD_LIBRARY_PATH=/system/vendor/quasar:/system/vendor/quasar/libs "
                   "GST_PLUGIN_PATH=/system/vendor/quasar/libs ./maind --gst-launch " + shlex.quote(pipeline) +
                   " >/tmp/cucumber-studio-audio-convert.log 2>&1; "
                   "[ -s " + shlex.quote(remote_output) + " ] || { cat /tmp/cucumber-studio-audio-convert.log; exit 31; }; echo AUDIO_CONVERT_OK")
            result = shell(cmd, timeout=90)
            if result.returncode != 0 or "AUDIO_CONVERT_OK" not in result.stdout:
                raise RuntimeError("Не удалось преобразовать файл в формат системного звука Opus. Попробуй загрузить корректный MP3/WAV/OGG/Opus. " + (result.stdout or result.stderr)[-1200:])
            source = remote_output
        else:
            if original_ext != upload_ext:
                raise ValueError("Этот системный звук не в формате Opus. Для него выбери файл с таким же расширением: " + (original_ext or "без расширения"))
            source = remote_input
        result = shell(remount_copy_script(path, source, make_backup=True), timeout=25)
        if result.returncode != 0 or "AUDIO_WRITE_OK" not in result.stdout:
            raise RuntimeError((result.stdout + "\n" + result.stderr)[-1600:] or "Не удалось заменить системный аудиофайл")
        return jsonify(ok=True, message="Файл заменён. Оригинал сохранён для восстановления.", path=path)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400
    finally:
        for tmp in (remote_input, remote_output):
            if tmp:
                try: shell("rm -f " + shlex.quote(tmp), timeout=4)
                except Exception: pass


@app.post("/api/audio/restore")
def audio_restore():
    try:
        path = validate_audio_path((request.get_json(silent=True) or {}).get("path"))
        backup = audio_backup_path(path)
        check = shell("[ -f " + shlex.quote(backup) + " ] && echo BACKUP || echo NONE", timeout=4)
        if check.stdout.strip() != "BACKUP":
            return jsonify(ok=False, error="Для этого файла нет сохранённой пользовательской замены."), 400
        result = shell(remount_copy_script(path, backup, make_backup=False), timeout=25)
        if result.returncode != 0 or "AUDIO_WRITE_OK" not in result.stdout:
            raise RuntimeError((result.stdout + "\n" + result.stderr)[-1200:] or "Не удалось восстановить оригинал")
        return jsonify(ok=True, message="Оригинальный файл восстановлен", path=path)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.post("/api/audio/restore-all")
def audio_restore_all():
    try:
        result = shell("find " + shlex.quote(AUDIO_BACKUP_ROOT) + " -type f -print 2>/dev/null | sort", timeout=10)
        backups = [line.strip() for line in result.stdout.splitlines() if line.strip().startswith(AUDIO_BACKUP_ROOT + "/")]
        if not backups:
            return jsonify(ok=True, restored=0, message="Пользовательских замен нет — все звуки уже исходные")
        restored, failures = 0, []
        prefix = AUDIO_BACKUP_ROOT + "/"
        current_paths = set(audio_paths())
        for backup in backups:
            rel = backup[len(prefix):]
            path = AUDIO_ROOT + "/" + rel
            try:
                if path not in current_paths:
                    failures.append(posixpath.basename(path) + ": файл больше не найден")
                    continue
                same = shell("cmp -s " + shlex.quote(path) + " " + shlex.quote(backup) + "; echo $?", timeout=6)
                if same.returncode == 0 and same.stdout.strip().endswith("0"):
                    continue
                one = shell(remount_copy_script(path, backup, make_backup=False), timeout=25)
                if one.returncode == 0 and "AUDIO_WRITE_OK" in one.stdout:
                    restored += 1
                else:
                    failures.append(posixpath.basename(path) + ": " + (one.stdout + one.stderr)[-300:])
            except Exception as exc:
                failures.append(posixpath.basename(path) + ": " + str(exc))
        if failures:
            return jsonify(ok=False, restored=restored, error=f"Восстановлено {restored}; ошибок: " + "; ".join(failures[:8])), 400
        return jsonify(ok=True, restored=restored, message=f"Восстановлено оригинальных файлов: {restored}")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/console")
def console_command():
    """Run a non-interactive shell command on the connected speaker as root."""
    data = request.get_json(silent=True) or {}
    command = str(data.get("command", "")).strip()
    if not command:
        return jsonify(ok=False, error="Введи команду."), 400
    if len(command) > 4000:
        return jsonify(ok=False, error="Команда слишком длинная (максимум 4000 символов)."), 400
    try:
        # Commands intentionally run as root on the user's own speaker.
        result = shell("sh -lc " + shlex.quote(command), timeout=20)
        output = result.stdout or ""
        if result.stderr:
            output += ("\n" if output else "") + result.stderr
        output = output[-24000:]
        return jsonify(ok=True, output=output, code=result.returncode)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/clock-toggle")
def clock_toggle():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", ""))
    stop_animation("clock")
    if not GROUPS["clock"].fullmatch(name):
        return jsonify(ok=False, error="Недопустимый сегмент циферблата."), 400
    try:
        current = read_brightness(name)
        value = 0 if current > 0 else 255
        write_led(name, value)
        return jsonify(ok=True, value=value, name=name)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/led")
def set_one():
    data = request.get_json(silent=True) or {}
    led_name = str(data.get("name", ""))
    stop_animation("clock" if GROUPS["clock"].fullmatch(led_name) else ("ring" if ":ring" in led_name else "logo" if ":logo" in led_name else None))
    try:
        value = write_led(str(data.get("name", "")), data.get("value", 0))
        return jsonify(ok=True, value=value)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/group")
def set_group():
    data = request.get_json(silent=True) or {}
    group = str(data.get("group", ""))
    stop_animation(group if group in _animation_events else None)
    if group not in GROUPS:
        return jsonify(ok=False, error="Неизвестная группа"), 400
    try:
        value = max(0, min(255, int(data.get("value", 0))))
        names = [n for n in led_names() if GROUPS[group].fullmatch(n)]
        for name in names: write_led(name, value)
        return jsonify(ok=True, changed=len(names), value=value)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/rgb")
def set_rgb():
    data = request.get_json(silent=True) or {}
    group = str(data.get("group", "ring"))
    stop_animation(group if group in ("ring", "logo") else None)
    if group not in ("ring", "logo"): return jsonify(ok=False, error="Группа должна быть ring или logo"), 400
    try:
        idx = int(data.get("index"))
        maximum = 24 if group == "ring" else 6
        if not (0 <= idx < maximum): raise ValueError("Индекс вне диапазона")
        rgb = [max(0, min(255, int(data.get(c, 0)))) for c in ("r","g","b")]
        for color, value in zip(("red","green","blue"), rgb):
            name = f"cucumber:{color}:{group}{idx}"
            if LED_RE.fullmatch(name): write_led(name, value)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/rgb-all")
def set_rgb_all():
    data = request.get_json(silent=True) or {}
    group = str(data.get("group", "ring"))
    stop_animation(group if group in ("ring", "logo") else None)
    if group not in ("ring", "logo"): return jsonify(ok=False, error="Неизвестная группа"), 400
    try:
        rgb = [max(0, min(255, int(data.get(c, 0)))) for c in ("r","g","b")]
        count = 24 if group == "ring" else 6
        for idx in range(count): set_rgb_group(group, idx, rgb)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/preset")
def preset():
    data = request.get_json(silent=True) or {}
    group = str(data.get("group", "ring"))
    stop_animation(group if group in ("ring", "logo") else None)
    name = str(data.get("preset", "rainbow"))
    if group not in ("ring", "logo"): return jsonify(ok=False, error="Неизвестная группа"), 400
    palettes = {
        "rainbow": [(255,0,0),(255,100,0),(255,220,0),(0,255,0),(0,180,255),(0,0,255),(150,0,255),(255,0,120)],
        "sunset": [(90,0,180),(180,0,255),(255,0,120),(255,50,30),(255,130,0),(255,220,50)],
        "ice": [(0,20,100),(0,80,255),(0,220,255),(100,255,255),(220,255,255)],
        "fire": [(255,0,0),(255,35,0),(255,90,0),(255,170,0),(255,230,20)],
        "green": [(0,255,30),(0,200,80),(0,100,40),(30,255,160)],
        "purple": [(70,0,255),(130,0,255),(220,0,255),(255,0,170)],
        "white": [(255,255,255)],
        "off": [(0,0,0)]
    }
    palette = palettes.get(name, palettes["rainbow"])
    count = 24 if group == "ring" else 6
    try:
        for i in range(count):
            color = palette[i % len(palette)]
            set_rgb_group(group, i, color)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

@app.post("/api/animation")
def animation():
    data = request.get_json(silent=True) or {}
    mode = str(data.get("mode", "stop"))
    group = str(data.get("group", "ring"))
    if group not in ("ring", "logo"): group = "ring"
    if mode == "stop":
        stop_animation(group)
        return jsonify(ok=True, running=False, group=group)
    if mode not in ("rainbow", "chase", "pulse"):
        return jsonify(ok=False, error="Неизвестная анимация"), 400
    try:
        speed = max(0.02, min(1.0, float(data.get("speed", 0.045))))
    except (TypeError, ValueError):
        return jsonify(ok=False, error="Некорректная скорость"), 400
    stop_animation(group)
    with _animation_lock:
        event = _animation_events[group]
        event.clear()
        generation = _animation_generations[group]
    count = 24 if group == "ring" else 6
    def runner():
        phase = 0
        while not event.is_set() and generation == _animation_generations[group]:
            try:
                colors = []
                for i in range(count):
                    if mode == "rainbow":
                        import colorsys
                        rgb = tuple(int(v*255) for v in colorsys.hsv_to_rgb((i/count + phase*0.008)%1, 1, 1))
                    elif mode == "chase":
                        d = (i-phase) % count
                        factor = 1 if d == 0 else (0.22 if d == 1 else 0)
                        rgb = (0, int(220*factor), int(255*factor))
                    else:
                        import math
                        factor = (math.sin(phase*0.22)+1)/2
                        rgb = (int(140*factor), int(30*factor), int(255*factor))
                    colors.append(rgb)
                set_rgb_frame(group, colors)
                phase += 1
                event.wait(speed)
            except Exception:
                # A temporary SSH failure should not end a 24/7 animation.
                if event.wait(1.0):
                    break
    thread = threading.Thread(target=runner, daemon=True, name=f"led-animation-{group}")
    with _animation_lock:
        _animation_threads[group] = thread
    thread.start()
    return jsonify(ok=True, running=True, mode=mode, group=group, speed=speed)

@app.post("/api/stop-animation")
def stop_animation_route():
    data = request.get_json(silent=True) or {}
    target = str(data.get("target", ""))
    if target not in ("ring", "logo", "clock"):
        return jsonify(ok=False, error="Неизвестная цель анимации."), 400
    stop_animation(target)
    return jsonify(ok=True, running=False, target=target)

@app.post("/api/custom-animation")
def custom_animation():
    """Play user-authored frames on RGB zones or clock LEDs."""
    data = request.get_json(silent=True) or {}
    target = str(data.get("target", "ring"))
    frames = data.get("frames")
    try:
        duration = max(0.05, min(5.0, float(data.get("duration", 300)) / 1000.0))
    except (TypeError, ValueError):
        return jsonify(ok=False, error="Некорректная длительность кадра."), 400
    loop = bool(data.get("loop", True))
    if target not in ("ring", "logo", "clock"):
        return jsonify(ok=False, error="Неизвестная цель анимации."), 400
    if not isinstance(frames, list) or not frames or len(frames) > 80:
        return jsonify(ok=False, error="Добавь от 1 до 80 кадров."), 400
    validated = []
    try:
        if target in ("ring", "logo"):
            count = 24 if target == "ring" else 6
            for frame in frames:
                colors = frame.get("colors") if isinstance(frame, dict) else None
                if not isinstance(colors, list) or len(colors) != count:
                    raise ValueError("В каждом RGB-кадре должны быть цвета всех зон.")
                parsed = []
                for color in colors:
                    if not isinstance(color, list) or len(color) != 3:
                        raise ValueError("Цвет должен содержать значения R, G и B.")
                    parsed.append([max(0, min(255, int(v))) for v in color])
                try: delay_before = max(0.0, min(10.0, float(frame.get("delay_before", 0)) / 1000.0))
                except (TypeError, ValueError): delay_before = 0.0
                validated.append({"colors": parsed, "delay_before": delay_before})
        else:
            known = set(led_names())
            clock_names = {name for name in known if GROUPS["clock"].fullmatch(name)}
            for frame in frames:
                values = frame.get("values") if isinstance(frame, dict) else None
                if not isinstance(values, dict):
                    raise ValueError("У кадра часов отсутствует карта сегментов.")
                parsed = {}
                for name, value in values.items():
                    if name not in clock_names:
                        raise ValueError("Кадр содержит неизвестный LED циферблата.")
                    parsed[name] = max(0, min(255, int(value)))
                try: delay_before = max(0.0, min(10.0, float(frame.get("delay_before", 0)) / 1000.0))
                except (TypeError, ValueError): delay_before = 0.0
                validated.append({"values": parsed, "delay_before": delay_before})
    except (TypeError, ValueError) as e:
        return jsonify(ok=False, error=str(e)), 400

    stop_animation(target)
    with _animation_lock:
        event = _animation_events[target]
        event.clear()
        generation = _animation_generations[target]
    def runner():
        try:
            while not event.is_set() and generation == _animation_generations[target]:
                try:
                    for frame in validated:
                        if event.is_set() or generation != _animation_generations[target]:
                            break
                        delay_before = frame.get("delay_before", 0.0)
                        if delay_before and event.wait(delay_before):
                            break
                        if event.is_set() or generation != _animation_generations[target]:
                            break
                        frame_started = time.monotonic()
                        if target in ("ring", "logo"):
                            set_rgb_frame(target, frame["colors"])
                        else:
                            set_clock_frame(frame["values"])
                        remaining = max(0.0, duration - (time.monotonic() - frame_started))
                        if event.wait(remaining):
                            break
                    if not loop:
                        break
                except Exception:
                    # Keep the animation alive across short SSH/Wi-Fi drops.
                    if event.wait(1.0):
                        break
        finally:
            # Don't clear the stop event here: another animation may have started.
            pass
    thread = threading.Thread(target=runner, daemon=True, name=f"custom-animation-{target}")
    with _animation_lock:
        _animation_threads[target] = thread
    thread.start()
    return jsonify(ok=True, running=True, target=target, frames=len(validated), loop=loop)

@app.post("/api/mode")
def mode():
    global screen_locked
    data = request.get_json(silent=True) or {}
    requested = bool(data.get("locked", False))
    # Only freeze/unfreeze maind when explicitly requested by the user.
    # A stopped daemon may interrupt normal clock/assistant LED behavior.
    try:
        if requested:
            r = shell("killall -STOP maind 2>/dev/null", 4)
        else:
            r = shell("killall -CONT maind 2>/dev/null", 4)
        screen_locked = requested
        return jsonify(ok=True, locked=screen_locked, note="Состояние отправлено колонке")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400

if __name__ == "__main__":
    print("Station MIDI (Cucumber) panel: http://127.0.0.1:8080")
    print("Enter the speaker IP, SSH port and root password in the UI.")
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8080")), threaded=True)

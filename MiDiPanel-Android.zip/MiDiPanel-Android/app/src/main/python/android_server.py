import os
import sys
import threading
import time
import socket

_server = None
_thread = None
PORT = 8765


def start_server(panel_dir):
    global _server, _thread

    if panel_dir not in sys.path:
        sys.path.insert(0, panel_dir)

    os.chdir(panel_dir)

    from app import app
    from werkzeug.serving import make_server

    if _server is None:
        _server = make_server(
            '127.0.0.1',
            PORT,
            app,
            threaded=True
        )

        _thread = threading.Thread(
            target=_server.serve_forever,
            name='MiDiPanel-Flask',
            daemon=True
        )

        _thread.start()

    deadline = time.time() + 15

    while time.time() < deadline:
        try:
            with socket.create_connection(
                ('127.0.0.1', PORT),
                timeout=0.4
            ):
                return 'http://127.0.0.1:%d/' % PORT

        except OSError:
            time.sleep(0.15)

    raise RuntimeError('Локальный сервер MiDi Panel не запустился')


def stop_server():
    global _server, _thread

    if _server is not None:
        _server.shutdown()
        _server = None
        _thread = None
